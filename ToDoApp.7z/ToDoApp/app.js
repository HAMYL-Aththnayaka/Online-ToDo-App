var express = require('express');
var todoController = require ('./controllers/todoController')

var app = express();

//setting up template engine
app.set('view engine','ejs');

//Static File usage
app.use(express.static('./public'));

//fire controllers
todoController(app);

//Listening to a port
app.listen(3000)
console.log(`You are Listening 3000}`);