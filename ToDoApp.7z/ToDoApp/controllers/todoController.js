var bodyParser = require('body-parser');
var mongoose = require('mongoose');

//conecting to the database
mongoose.connect('mongodb+srv://2021ict14:Yasas%402002@cluster0.ggej3pn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');

//Create a schema - this is a bluprint like sample
var todoSchema = new mongoose.Schema({
    item: String
});

var Todo = mongoose.model('Todo', todoSchema);


/*async function saveItem() {
    try {
        const itemOne = new Todo({ item: 'get The data' });
        await itemOne.save();
        console.log('Item Saved');
    } catch (err) {
        console.error(err);
    }
}
saveItem();
var data = [{item: 'get milk'},{item :'walk dog'},{item:'kick some codeing ass'}];
*/

var urlencodedParser = bodyParser.urlencoded({ extended: false });

module.exports = function(app) {

    app.get('/todo', async function(req, res) {
        //get data from mongodb
        try {
            const data = await Todo.find();
            res.render('todo', { todos: data });
        } catch (err) {
            throw err;
        }
    });

    app.post('/todo', urlencodedParser, async function(req, res) {
        //get data from view and add it to mongodb
        try {
            var newTodo = new Todo(req.body);
            const data = await newTodo.save();
            res.json(data); 
        } catch (err) {
            throw err;
        }
    });

    app.delete('/todo/:item', async function(req, res) {
        //delete the rewuested data
        try {
            const data = await Todo.deleteOne({ item: req.params.item.replace(/\*/g, " ") });
            res.json(data);
        } catch (err) {
            throw err;
        }
    });

};
